"use client"

import React, {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react"

import { useTheme } from "@/contexts/theme-context"
import {
  Sun,
  Moon,
  LayoutGrid,
  TicketCheck,
  Clock,
  PhoneCall,
  TrendingUp,
} from "lucide-react"

import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
  Sector,
  LabelList,
} from "recharts"

// ============================================================
// TYPES
// ============================================================

type ModeType = "monthly" | "quarterly" | "yearly"

interface SummaryData {
  total_ticket: number
  aht: string
  art: string
  awt: string
}

interface TrendData { label: string; count: number }
interface NamedCount { name: string; count: number }

interface TopCase {
  rank: number
  title: string
  count: number
  channel: string
}

interface CustomerData {
  label: string
  total: number
  new: number
}

interface OmnixResponse {
  summary?: SummaryData
  trend?: TrendData[]
  channel?: NamedCount[]
  category?: NamedCount[]
  product?: NamedCount[]
  top_cases?: TopCase[]
  customer?: CustomerData[]
}

// ============================================================
// CONSTANTS
// ============================================================

const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8001/api/dashboard"

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]
const QUARTERS = ["Q1", "Q2", "Q3", "Q4"]
const PALETTE = [
  "#0ea5e9", "#6366f1", "#f59e0b", "#10b981",
  "#f43f5e", "#8b5cf6", "#06b6d4",
]

const SPACING = {
  cardPadding: 18,
  cardGap: 14,
  headerPadding: "14px 18px",
  controlHeight: 32,
} as const

const fmt = (n: number) => new Intl.NumberFormat("id-ID").format(n)

// ============================================================
// DUMMY DATA
// ============================================================

const DUMMY: Required<OmnixResponse> = {
  summary: {
    total_ticket: 12450,
    aht: "8m 32s",
    art: "2m 10s",
    awt: "1m 45s",
  },
  trend: MONTHS.map((m, i) => ({
    label: m,
    count: 800 + Math.round(Math.sin(i * 0.6) * 200) + i * 30,
  })),
  channel: [
    { name: "WhatsApp", count: 5200 },
    { name: "IG Message", count: 2800 },
    { name: "Voice", count: 1900 },
    { name: "Email", count: 1400 },
    { name: "Manual", count: 1150 },
  ],
  category: [
    { name: "Complaint", count: 4100 },
    { name: "Inquiry", count: 3200 },
    { name: "Request", count: 2300 },
    { name: "Follow Up", count: 1500 },
    { name: "Feedback", count: 900 },
    { name: "Others", count: 450 },
  ],
  product: [
    { name: "Product A", count: 3800 },
    { name: "Product B", count: 2900 },
    { name: "Product C", count: 2100 },
    { name: "Product D", count: 1800 },
    { name: "Product E", count: 1200 },
    { name: "Others", count: 650 },
  ],
  top_cases: [
    { rank: 1, title: "Refund tidak diproses", count: 320, channel: "WhatsApp" },
    { rank: 2, title: "Produk tidak sesuai", count: 274, channel: "IG Message" },
    { rank: 3, title: "Pengiriman terlambat", count: 231, channel: "WhatsApp" },
    { rank: 4, title: "Akun tidak bisa login", count: 198, channel: "Email" },
    { rank: 5, title: "Promo tidak bisa digunakan", count: 165, channel: "Voice" },
  ],
  customer: MONTHS.map((m, i) => ({
    label: m,
    total: 4000 + i * 120,
    new: 300 + Math.round(Math.sin(i * 0.7) * 80) + 50,
  })),
}

// ============================================================
// UI COMPONENTS
// ============================================================

const cardStyle: React.CSSProperties = {
  background: "var(--c-surface)",
  border: "1px solid var(--c-border)",
  borderRadius: 14,
  overflow: "hidden",
  boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
}

function Card({
  children,
  style,
}: {
  children: React.ReactNode
  style?: React.CSSProperties
}) {
  return <div style={{ ...cardStyle, ...style }}>{children}</div>
}

function CardHeader({
  title,
  badge,
  extra,
}: {
  title: string
  badge?: string
  extra?: React.ReactNode
}) {
  return (
    <div
      style={{
        padding: SPACING.headerPadding,
        borderBottom: "1px solid var(--c-border)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 8,
        minHeight: 44,
      }}
    >
      <span
        style={{
          fontSize: 12,
          fontWeight: 700,
          letterSpacing: 0.2,
          color: "var(--c-text)",
        }}
      >
        {title}
      </span>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        {extra}
        {badge && (
          <span
            style={{
              fontSize: 9,
              fontWeight: 800,
              letterSpacing: 0.5,
              padding: "3px 9px",
              borderRadius: 99,
              background: "rgba(34,197,94,0.12)",
              color: "#22c55e",
              border: "1px solid rgba(34,197,94,0.2)",
            }}
          >
            {badge}
          </span>
        )}
      </div>
    </div>
  )
}

function VDivider() {
  return (
    <span
      style={{
        display: "block",
        width: 1,
        height: 18,
        flexShrink: 0,
        background: "var(--c-border)",
      }}
    />
  )
}

function Skeleton({
  w = 80,
  h = 28,
}: {
  w?: number | string
  h?: number | string
}) {
  return (
    <div
      style={{
        width: w,
        height: h,
        borderRadius: 6,
        background: "var(--c-skeleton)",
        animation: "pulse 1.5s ease-in-out infinite",
      }}
    />
  )
}

/**
 * Skeleton chart — bar shimmer dengan tinggi natural.
 */
function ChartSkeleton({
  bars = 12,
  showYAxis = true,
}: {
  bars?: number
  showYAxis?: boolean
}) {
  const heights = useMemo(
  () =>
    Array.from({ length: bars }, (_, i) => {
      const base =
        50 +
        Math.sin(i * 0.5) * 25 +
        Math.cos(i * 0.3) * 15

      return Math.max(
        25,
        Math.min(95, Number(base.toFixed(1)) + 25)
      )
    }),
  [bars]
)

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        gap: 8,
      }}
    >
      <div
        style={{
          flex: 1,
          display: "flex",
          alignItems: "flex-end",
          gap: bars > 20 ? 3 : 6,
          paddingLeft: showYAxis ? 32 : 0,
          paddingRight: 8,
          paddingTop: 8,
          position: "relative",
        }}
      >
        {showYAxis && (
          <div
            style={{
              position: "absolute",
              left: 0,
              top: 8,
              bottom: 0,
              width: 26,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              alignItems: "flex-end",
              paddingRight: 6,
            }}
          >
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                style={{
                  width: 18,
                  height: 6,
                  borderRadius: 3,
                  background: "var(--c-skeleton)",
                  opacity: 0.5,
                }}
              />
            ))}
          </div>
        )}

        {heights.map((h, i) => (
          <div
            key={i}
            className="shimmer-bar"
            style={{
              flex: 1,
              height: `${h}%`,
              borderRadius: "4px 4px 0 0",
              animationDelay: `${i * 0.04}s, ${i * 0.06}s`,
            }}
          />
        ))}
      </div>

      <div
        style={{
          display: "flex",
          gap: bars > 20 ? 3 : 6,
          paddingLeft: showYAxis ? 32 : 0,
          paddingRight: 8,
        }}
      >
        {heights.map((_, i) => (
          <div
            key={i}
            style={{
              flex: 1,
              height: 6,
              borderRadius: 3,
              background: "var(--c-skeleton)",
              opacity: 0.4,
            }}
          />
        ))}
      </div>
    </div>
  )
}

/**
 * Skeleton donut — circle dengan shimmer.
 */
function DonutSkeleton() {
  return (
    <div
      style={{
        height: 150,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        className="shimmer-circle"
        style={{
          width: 124,
          height: 124,
          borderRadius: "50%",
          mask: "radial-gradient(circle, transparent 38%, black 39%)",
          WebkitMask: "radial-gradient(circle, transparent 38%, black 39%)",
        }}
      />
    </div>
  )
}

/**
 * Skeleton untuk BarList rows.
 */
function BarListSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <ul
      style={{
        listStyle: "none",
        padding: 0,
        margin: 0,
        display: "flex",
        flexDirection: "column",
        gap: 11,
      }}
    >
      {Array.from({ length: rows }).map((_, i) => (
        <li key={i}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: 5,
            }}
          >
            <Skeleton
  w={`${50 + ((i * 7) % 30)}%`}
  h={11}
/>
            <Skeleton w={32} h={11} />
          </div>
          <Skeleton w="100%" h={5} />
        </li>
      ))}
    </ul>
  )
}

/**
 * Skeleton row untuk Top Cases table.
 */
function TopCaseRowSkeleton() {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "32px 1fr 90px 90px",
        padding: "10px 0",
        gap: 12,
        alignItems: "center",
        borderBottom: "1px solid var(--c-border)",
      }}
    >
      <Skeleton w={18} h={14} />
      <Skeleton w="70%" h={12} />
      <div style={{ display: "flex", justifyContent: "center" }}>
        <Skeleton w={64} h={16} />
      </div>
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <Skeleton w={40} h={12} />
      </div>
    </div>
  )
}

function PeriodDropdown({
  options,
  value,
  onChange,
  isDark,
  width,
}: {
  options: string[]
  value: string
  onChange: (value: string) => void
  isDark: boolean
  width?: number | string
}) {
  const chevronColor = isDark ? "%23e2e4ea" : "%231a1d27"
  const chevronSvg = `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='${chevronColor}' stroke-width='3' stroke-linecap='round' stroke-linejoin='round'><polyline points='6 9 12 15 18 9'></polyline></svg>")`

  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        height: SPACING.controlHeight,
        width,
        padding: "0 28px 0 12px",
        borderRadius: 8,
        border: "1px solid var(--c-border)",
        background: `var(--c-control) ${chevronSvg} no-repeat right 10px center`,
        color: "var(--c-text)",
        fontSize: 11,
        fontWeight: 600,
        appearance: "none",
        WebkitAppearance: "none",
        MozAppearance: "none",
        cursor: "pointer",
        outline: "none",
        transition: "border-color 0.15s, background-color 0.15s",
      }}
      onFocus={(e) => (e.currentTarget.style.borderColor = "var(--c-accent)")}
      onBlur={(e) => (e.currentTarget.style.borderColor = "var(--c-border)")}
    >
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  )
}

/**
 * Custom tooltip — multi-series support.
 */
interface TooltipPayload {
  dataKey?: string
  name?: string
  value: number
  fill?: string
  color?: string
}

function CustomTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean
  payload?: TooltipPayload[]
  label?: string
}) {
  if (!active || !payload?.length) return null
  return (
    <div
      style={{
        background: "var(--c-surface)",
        border: "1px solid var(--c-border)",
        borderRadius: 10,
        padding: "10px 14px",
        boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
        minWidth: 140,
      }}
    >
      <p
        style={{
          color: "var(--c-muted)",
          marginBottom: 6,
          fontSize: 10,
          fontWeight: 700,
          letterSpacing: 0.6,
          textTransform: "uppercase",
        }}
      >
        {label}
      </p>
      {payload.map((p, idx) => (
        <div
          key={p.dataKey ?? idx}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            padding: "2px 0",
          }}
        >
          <span
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: p.fill ?? p.color,
              flexShrink: 0,
            }}
          />
          <span style={{ color: "var(--c-muted)", fontSize: 11 }}>
            {p.name}
          </span>
          <span
            style={{
              fontWeight: 700,
              color: "var(--c-text)",
              marginLeft: "auto",
              paddingLeft: 12,
              fontSize: 11,
            }}
          >
            {typeof p.value === "number" ? fmt(p.value) : p.value}
          </span>
        </div>
      ))}
    </div>
  )
}

/**
 * BarList — horizontal bar list reusable.
 */
function BarList({
  items,
  maxCount,
}: {
  items: NamedCount[]
  maxCount: number
}) {
  return (
    <ul
      style={{
        listStyle: "none",
        padding: 0,
        margin: 0,
        display: "flex",
        flexDirection: "column",
        gap: 11,
      }}
    >
      {items.slice(0, 7).map((item, i) => {
        const pct = maxCount ? (item.count / maxCount) * 100 : 0
        return (
          <li key={item.name}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                fontSize: 11,
                marginBottom: 5,
              }}
            >
              <span
                style={{
                  color: "var(--c-muted)",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {item.name}
              </span>
              <span
                style={{
                  color: "var(--c-text)",
                  fontWeight: 700,
                  fontVariantNumeric: "tabular-nums",
                  marginLeft: 8,
                  flexShrink: 0,
                }}
              >
                {fmt(item.count)}
              </span>
            </div>
            <div
              style={{
                height: 5,
                borderRadius: 99,
                background: "var(--c-border)",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  height: "100%",
                  width: `${pct}%`,
                  borderRadius: 99,
                  background: PALETTE[i % PALETTE.length],
                  transition: "width 0.6s ease",
                }}
              />
            </div>
          </li>
        )
      })}
    </ul>
  )
}

// ============================================================
// MEMOIZED CHARTS
// ============================================================

/**
 * TrendChart — bar chart dgn highlight peak.
 */
const TrendChart = memo(function TrendChart({
  data,
  gridColor,
  tickColor,
  isDark,
}: {
  data: TrendData[]
  gridColor: string
  tickColor: string
  isDark: boolean
}) {
  const maxCount = useMemo(
    () => Math.max(...data.map((d) => d.count), 0),
    [data]
  )
  const peakColor = "#6366f1"
  const dimColor = isDark ? "rgba(99,102,241,0.4)" : "rgba(99,102,241,0.55)"

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{ top: 22, right: 4, bottom: 0, left: 0 }}
        barCategoryGap="30%"
      >
        <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
        <XAxis
          dataKey="label"
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          dy={8}
          tick={{ fill: tickColor, fontSize: 10 }}
        />
        <YAxis
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          width={36}
          tick={{ fill: tickColor, fontSize: 10 }}
          tickFormatter={(v: number) =>
            v >= 1000 ? `${(v / 1000).toFixed(1)}k` : String(v)
          }
        />
        <Tooltip
          content={<CustomTooltip />}
          cursor={{ fill: isDark ? "rgba(255,255,255,0.025)" : "rgba(0,0,0,0.04)" }}
        />
        <Bar
          dataKey="count"
          name="Tickets"
          radius={[5, 5, 0, 0]}
          maxBarSize={36}
          isAnimationActive={false}
        >
          {data.map((entry, i) => {
            const isPeak = entry.count === maxCount && maxCount > 0
            return (
              <Cell
                key={i}
                fill={isPeak ? peakColor : dimColor}
                stroke={isPeak ? peakColor : "none"}
                strokeWidth={isPeak ? 1 : 0}
              />
            )
          })}
          <LabelList
            dataKey="count"
            position="top"
            style={{ fontSize: 9, fontWeight: 600, fill: tickColor }}
            formatter={(val: number) =>
              val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val
            }
          />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
})

/**
 * ChannelDonut — pie chart dgn interactive legend.
 */
const ChannelDonut = memo(function ChannelDonut({
  data,
  total,
  activeIndex,
  onActiveChange,
}: {
  data: Array<NamedCount & { pct: number }>
  total: number
  activeIndex: number | null
  onActiveChange: (idx: number | null) => void
}) {
  return (
    <ResponsiveContainer width="100%" height={150}>
      <PieChart>
        <Pie
          data={data}
          dataKey="count"
          cx="50%"
          cy="50%"
          outerRadius={62}
          innerRadius={44}
          paddingAngle={3}
          cornerRadius={3}
          stroke="none"
          onMouseEnter={(_, i) => onActiveChange(i)}
          onMouseLeave={() => onActiveChange(null)}
          activeIndex={activeIndex ?? undefined}
          activeShape={(props: {
            cx: number
            cy: number
            innerRadius: number
            outerRadius: number
            startAngle: number
            endAngle: number
            fill: string
          }) => {
            const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill } = props
            return (
              <Sector
                cx={cx}
                cy={cy}
                innerRadius={innerRadius - 2}
                outerRadius={outerRadius + 6}
                startAngle={startAngle}
                endAngle={endAngle}
                fill={fill}
                style={{ filter: `drop-shadow(0 0 5px ${fill}80)` }}
              />
            )
          }}
        >
          {data.map((_, i) => (
            <Cell
              key={i}
              fill={PALETTE[i % PALETTE.length]}
              opacity={activeIndex !== null && i !== activeIndex ? 0.35 : 1}
              style={{ transition: "opacity 0.2s", cursor: "pointer" }}
            />
          ))}
        </Pie>
        <text x="50%" y="50%" textAnchor="middle" dominantBaseline="central">
          <tspan x="50%" dy="-5" fontSize="18" fontWeight="800" fill="var(--c-text)">
            {total >= 1000 ? `${(total / 1000).toFixed(1)}k` : total}
          </tspan>
          <tspan
            x="50%"
            dy="15"
            fontSize="8"
            fontWeight="600"
            fill="var(--c-muted)"
            letterSpacing="0.06em"
          >
            TOTAL
          </tspan>
        </text>
      </PieChart>
    </ResponsiveContainer>
  )
})

/**
 * CustomerLineChart — multi-line: total + new customer.
 */
const CustomerLineChart = memo(function CustomerLineChart({
  data,
  gridColor,
  tickColor,
}: {
  data: CustomerData[]
  gridColor: string
  tickColor: string
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
        <XAxis
          dataKey="label"
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          dy={8}
          tick={{ fill: tickColor, fontSize: 10 }}
        />
        <YAxis
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          width={36}
          tick={{ fill: tickColor, fontSize: 10 }}
          tickFormatter={(v: number) =>
            v >= 1000 ? `${(v / 1000).toFixed(1)}k` : String(v)
          }
        />
        <Tooltip content={<CustomTooltip />} />
        <Line
          type="monotone"
          dataKey="total"
          name="Total Customer"
          stroke="#0ea5e9"
          strokeWidth={2.5}
          dot={{ r: 3, fill: "#0ea5e9" }}
          activeDot={{ r: 5 }}
          isAnimationActive={false}
        />
        <Line
          type="monotone"
          dataKey="new"
          name="New Customer"
          stroke="#22c55e"
          strokeWidth={2.5}
          dot={{ r: 3, fill: "#22c55e" }}
          activeDot={{ r: 5 }}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  )
})

/**
 * NewCustomerBarChart — peak highlighted + value labels.
 */
const NewCustomerBarChart = memo(function NewCustomerBarChart({
  data,
  gridColor,
  tickColor,
  isDark,
}: {
  data: CustomerData[]
  gridColor: string
  tickColor: string
  isDark: boolean
}) {
  const maxNew = useMemo(
    () => Math.max(...data.map((d) => d.new), 0),
    [data]
  )
  const peakColor = "#22c55e"
  const dimColor = isDark ? "rgba(34,197,94,0.4)" : "rgba(34,197,94,0.55)"

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={data}
        margin={{ top: 22, right: 4, bottom: 0, left: 0 }}
        barCategoryGap="30%"
      >
        <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
        <XAxis
          dataKey="label"
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          dy={8}
          tick={{ fill: tickColor, fontSize: 10 }}
        />
        <YAxis
          stroke="transparent"
          tickLine={false}
          axisLine={false}
          width={32}
          tick={{ fill: tickColor, fontSize: 10 }}
        />
        <Tooltip
          content={<CustomTooltip />}
          cursor={{ fill: isDark ? "rgba(255,255,255,0.025)" : "rgba(0,0,0,0.04)" }}
        />
        <Bar
          dataKey="new"
          name="New Customer"
          radius={[5, 5, 0, 0]}
          maxBarSize={30}
          isAnimationActive={false}
        >
          {data.map((entry, i) => {
            const isPeak = entry.new === maxNew && maxNew > 0
            return (
              <Cell
                key={i}
                fill={isPeak ? peakColor : dimColor}
                stroke={isPeak ? peakColor : "none"}
                strokeWidth={isPeak ? 1 : 0}
              />
            )
          })}
          <LabelList
            dataKey="new"
            position="top"
            style={{ fontSize: 9, fontWeight: 600, fill: tickColor }}
          />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
})

// ============================================================
// PAGE
// ============================================================

export default function OmnixPage() {
  const { isDark, toggleTheme } = useTheme()

  const [mode, setMode] = useState<ModeType>("monthly")
  const [period, setPeriod] = useState("Jan")
  const [year, setYear] = useState(2026)
  const [pieActive, setPieActive] = useState<number | null>(null)

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [summary, setSummary] = useState<SummaryData>({
  total_ticket: 0,
  aht: "0s",
  art: "0s",
  awt: "0s",
})
  const [trend, setTrend] = useState<TrendData[]>([])
  const [channel, setChannel] = useState<NamedCount[]>([])
  const [category, setCategory] = useState<NamedCount[]>([])
  const [product, setProduct] = useState<NamedCount[]>([])
  const [topCases, setTopCases] = useState<TopCase[]>([])
  const [customer, setCustomer] = useState<CustomerData[]>([])

  const debounceRef = useRef<NodeJS.Timeout | null>(null)

  // Reset period saat mode berubah
  useEffect(() => {
    if (mode === "monthly") setPeriod("Jan")
    else if (mode === "quarterly") setPeriod("Q1")
    else setPeriod("all")
  }, [mode])

  const fetchData = useCallback(async () => {
    setLoading(true)
    setError(null)

    try {
      const safePeriod =
        mode === "yearly"
          ? "all"
          : mode === "quarterly"
            ? period.startsWith("Q") ? period : "Q1"
            : period

      const qs = new URLSearchParams({
        mode,
        period: safePeriod,
        year: String(year),
      })

      const res = await fetch(`${API_BASE}/all?${qs.toString()}`, {
        cache: "no-store",
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const json: OmnixResponse = await res.json()

      setSummary(
  json.summary ?? {
    total_ticket: 0,
    aht: "0s",
    art: "0s",
    awt: "0s",
  }
)

setTrend(
  Array.isArray(json.trend)
    ? json.trend
    : []
)

setChannel(
  Array.isArray(json.channel)
    ? json.channel
    : []
)

setCategory(
  Array.isArray(json.category)
    ? json.category
    : []
)

setProduct(
  Array.isArray(json.product)
    ? json.product
    : []
)

setTopCases(
  Array.isArray(json.top_cases)
    ? json.top_cases
    : []
)

setCustomer(
  Array.isArray(json.customer)
    ? json.customer
    : []
)
    } catch (err) {
      console.error("Omnix fetch error:", err)
      setError(err instanceof Error ? err.message : "Failed to fetch data")
    } finally {
      setLoading(false)
    }
  }, [mode, period, year])

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => fetchData(), 250)
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current)
    }
  }, [fetchData])

  // Derived
  const channelTotal = useMemo(
    () => channel.reduce((s, c) => s + (c.count || 0), 0),
    [channel]
  )
  const channelPie = useMemo(
    () =>
      channel.map((c) => ({
        ...c,
        pct: channelTotal ? Math.round((c.count / channelTotal) * 100) : 0,
      })),
    [channel, channelTotal]
  )
  const catMax = useMemo(
    () => Math.max(...category.map((c) => c.count || 0), 0),
    [category]
  )
  const prodMax = useMemo(
    () => Math.max(...product.map((p) => p.count || 0), 0),
    [product]
  )

  const periodOptions = useMemo(() => {
    switch (mode) {
      case "monthly": return MONTHS
      case "quarterly": return QUARTERS
      default: return []
    }
  }, [mode])

  // Theme variables
  const cssVars: React.CSSProperties = isDark
    ? ({
        "--c-bg": "#0d1117",
        "--c-surface": "#161b22",
        "--c-control": "#1f242d",
        "--c-border": "rgba(255,255,255,0.08)",
        "--c-text": "#e2e4ea",
        "--c-muted": "#6b7485",
        "--c-skeleton": "#252a35",
        "--c-skeleton-shine": "rgba(255,255,255,0.06)",
        "--c-accent": "#6366f1",
      } as React.CSSProperties)
    : ({
        "--c-bg": "#f0f2f5",
        "--c-surface": "#ffffff",
        "--c-control": "#f7f8fa",
        "--c-border": "rgba(0,0,0,0.08)",
        "--c-text": "#1a1d27",
        "--c-muted": "#6b7280",
        "--c-skeleton": "#e5e7eb",
        "--c-skeleton-shine": "rgba(255,255,255,0.8)",
        "--c-accent": "#6366f1",
      } as React.CSSProperties)

  const gridColor = isDark ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.05)"
  const tickColor = isDark ? "#6b7485" : "#9ca3af"

  const KPI_CARDS = useMemo(
    () => [
      {
        label: "Total Ticket",
        value: fmt(summary.total_ticket || 0),
        color: "#0ea5e9",
        icon: TicketCheck,
      },
      {
        label: "Avg Handle Time",
        value: summary.aht || "0s",
        color: "#8b5cf6",
        icon: Clock,
      },
      {
        label: "Avg Response Time",
        value: summary.art || "0s",
        color: "#f59e0b",
        icon: PhoneCall,
      },
      {
        label: "Avg Wait Time",
        value: summary.awt || "0s",
        color: "#10b981",
        icon: TrendingUp,
      },
    ],
    [summary]
  )

  return (
    <div
      style={{
        ...cssVars,
        background: "var(--c-bg)",
        minHeight: "100vh",
        color: "var(--c-text)",
        fontFamily: "'Plus Jakarta Sans','Inter','Segoe UI',sans-serif",
        transition: "background 0.25s, color 0.25s",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1 }
          50% { opacity: 0.4 }
        }

        @keyframes shimmer {
          0% { background-position: -400px 0; }
          100% { background-position: 400px 0; }
        }

        @keyframes barBreathe {
          0%, 100% { transform: scaleY(0.85); opacity: 0.7; }
          50% { transform: scaleY(1); opacity: 1; }
        }

        * { box-sizing: border-box; }

        button { outline: none; font-family: inherit; }
        button:focus-visible {
          outline: 2px solid var(--c-accent);
          outline-offset: 2px;
        }

        select option {
          background: var(--c-surface);
          color: var(--c-text);
        }

        .icon-btn:hover {
          background: var(--c-control) !important;
          border-color: var(--c-accent) !important;
        }

        .shimmer-bar {
          background: linear-gradient(
            90deg,
            var(--c-skeleton) 0%,
            var(--c-skeleton-shine) 50%,
            var(--c-skeleton) 100%
          );
          background-size: 800px 100%;
          transform-origin: bottom center;
          animation:
            shimmer 1.8s linear infinite,
            barBreathe 1.6s ease-in-out infinite;
        }

        .shimmer-circle {
          background: linear-gradient(
            90deg,
            var(--c-skeleton) 0%,
            var(--c-skeleton-shine) 50%,
            var(--c-skeleton) 100%
          );
          background-size: 800px 100%;
          animation: shimmer 1.8s linear infinite;
        }
      `}</style>

      {/* HEADER */}
      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 30,
          background: "var(--c-surface)",
          borderBottom: "1px solid var(--c-border)",
          height: 60,
          padding: "0 20px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            flexShrink: 0,
          }}
        >
          <span
            style={{
              width: 32,
              height: 32,
              borderRadius: 9,
              flexShrink: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              background: "rgba(99,102,241,0.12)",
            }}
          >
            <LayoutGrid size={15} color="#6366f1" />
          </span>
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.2 }}>
            <span
              style={{
                fontWeight: 800,
                fontSize: 13,
                letterSpacing: 0.3,
                color: "var(--c-text)",
              }}
            >
              OMNIX Reporting
            </span>
            <span
              style={{
                fontSize: 10,
                color: "var(--c-muted)",
                marginTop: 2,
              }}
            >
              {mode === "yearly" ? `Full Year ${year}` : `${period} · ${year}`}
            </span>
          </div>
        </div>

        {/* Filter group */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <PeriodDropdown
            options={["Monthly", "Quarterly", "Yearly"]}
            value={mode.charAt(0).toUpperCase() + mode.slice(1)}
            onChange={(v) => setMode(v.toLowerCase() as ModeType)}
            isDark={isDark}
            width={110}
          />
          {mode !== "yearly" && (
            <PeriodDropdown
              options={periodOptions}
              value={period}
              onChange={setPeriod}
              isDark={isDark}
              width={90}
            />
          )}
          <PeriodDropdown
            options={["2024", "2025", "2026"]}
            value={String(year)}
            onChange={(v) => setYear(Number(v))}
            isDark={isDark}
            width={84}
          />
          <button
            className="icon-btn"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            style={{
              width: SPACING.controlHeight,
              height: SPACING.controlHeight,
              borderRadius: 8,
              border: "1px solid var(--c-border)",
              background: "var(--c-control)",
              color: "var(--c-text)",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "all 0.15s",
              flexShrink: 0,
            }}
          >
            {isDark ? <Sun size={14} /> : <Moon size={14} />}
          </button>
        </div>
      </header>

      {/* ERROR BANNER */}
      {error && (
        <div
          style={{
            margin: "16px 20px 0",
            padding: "12px 16px",
            borderRadius: 10,
            background: "rgba(239,68,68,0.08)",
            border: "1px solid rgba(239,68,68,0.2)",
            color: "#ef4444",
            fontSize: 12,
            fontWeight: 600,
          }}
        >
          Failed to fetch data: {error}
        </div>
      )}

      {/* MAIN */}
      <main
        style={{
          flex: 1,
          padding: 20,
          maxWidth: 1400,
          width: "100%",
          margin: "0 auto",
          display: "flex",
          flexDirection: "column",
          gap: SPACING.cardGap,
        }}
      >
        {/* KPI CARDS */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4,1fr)",
            gap: 12,
          }}
        >
          {KPI_CARDS.map((kpi) => {
            const Icon = kpi.icon
            return (
              <Card key={kpi.label}>
                <div
                  style={{
                    padding: "14px 16px",
                    display: "flex",
                    flexDirection: "column",
                    gap: 11,
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "flex-start",
                      justifyContent: "space-between",
                      gap: 6,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        letterSpacing: 0.6,
                        textTransform: "uppercase",
                        color: "var(--c-muted)",
                        lineHeight: 1.5,
                      }}
                    >
                      {kpi.label}
                    </span>
                    <span
                      style={{
                        width: 28,
                        height: 28,
                        borderRadius: 8,
                        flexShrink: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        background: `${kpi.color}18`,
                      }}
                    >
                      <Icon size={13} color={kpi.color} strokeWidth={2.2} />
                    </span>
                  </div>
                  {loading ? (
                    <Skeleton w={70} h={24} />
                  ) : (
                    <span
                      style={{
                        fontSize: 22,
                        fontWeight: 700,
                        letterSpacing: -0.5,
                        fontVariantNumeric: "tabular-nums",
                        color: "var(--c-text)",
                        lineHeight: 1,
                      }}
                    >
                      {kpi.value}
                    </span>
                  )}
                  <div
                    style={{
                      height: 2,
                      borderRadius: 99,
                      background: `${kpi.color}20`,
                      overflow: "hidden",
                    }}
                  >
                    <div
                      style={{
                        height: "100%",
                        width: loading ? "0%" : "60%",
                        background: kpi.color,
                        borderRadius: 99,
                        transition: "width 1s ease",
                      }}
                    />
                  </div>
                </div>
              </Card>
            )
          })}
        </div>

        {/* INTERACTION TREND */}
        <Card>
          <CardHeader
            title="Interaction Trend"
            badge={loading ? undefined : "LIVE"}
            extra={
              !loading && (
                <span style={{ fontSize: 10, color: "var(--c-muted)" }}>
                  Peak month highlighted
                </span>
              )
            }
          />
          <div style={{ padding: SPACING.cardPadding, height: 260 }}>
            {loading ? (
              <ChartSkeleton bars={12} />
            ) : (
              <TrendChart
                data={trend}
                gridColor={gridColor}
                tickColor={tickColor}
                isDark={isDark}
              />
            )}
          </div>
        </Card>

        {/* CHANNEL | CATEGORY | PRODUCT */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: SPACING.cardGap,
          }}
        >
          {/* Channel — Donut + list */}
          <Card>
            <CardHeader title="Channel" />
            <div style={{ padding: SPACING.cardPadding }}>
              {loading ? (
                <>
                  <DonutSkeleton />
                  <div style={{ marginTop: 8 }}>
                    <BarListSkeleton rows={5} />
                  </div>
                </>
              ) : (
                <>
                  <ChannelDonut
                    data={channelPie}
                    total={channelTotal}
                    activeIndex={pieActive}
                    onActiveChange={setPieActive}
                  />

                  <ul
                    style={{
                      listStyle: "none",
                      padding: 0,
                      margin: "8px 0 0",
                      display: "flex",
                      flexDirection: "column",
                      gap: 1,
                    }}
                  >
                    {channelPie.map((c, i) => (
                      <li
                        key={c.name}
                        onMouseEnter={() => setPieActive(i)}
                        onMouseLeave={() => setPieActive(null)}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 8,
                          padding: "5px 6px",
                          borderRadius: 8,
                          cursor: "pointer",
                          transition: "background 0.15s",
                          background:
                            pieActive === i
                              ? `${PALETTE[i % PALETTE.length]}12`
                              : "transparent",
                          opacity:
                            pieActive !== null && i !== pieActive ? 0.4 : 1,
                        }}
                      >
                        <span
                          style={{
                            width: 8,
                            height: 8,
                            borderRadius: "50%",
                            flexShrink: 0,
                            background: PALETTE[i % PALETTE.length],
                          }}
                        />
                        <span
                          style={{
                            flex: 1,
                            fontSize: 11,
                            color: "var(--c-text)",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {c.name}
                        </span>
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            color: "var(--c-text)",
                            fontVariantNumeric: "tabular-nums",
                          }}
                        >
                          {fmt(c.count || 0)}
                        </span>
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            color: PALETTE[i % PALETTE.length],
                            minWidth: 30,
                            textAlign: "right",
                          }}
                        >
                          {c.pct}%
                        </span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </Card>

          {/* Category */}
          <Card>
            <CardHeader title="Category" />
            <div style={{ padding: SPACING.cardPadding }}>
              {loading ? (
                <BarListSkeleton rows={6} />
              ) : (
                <BarList items={category} maxCount={catMax} />
              )}
            </div>
          </Card>

          {/* Product */}
          <Card>
            <CardHeader title="Product" />
            <div style={{ padding: SPACING.cardPadding }}>
              {loading ? (
                <BarListSkeleton rows={6} />
              ) : (
                <BarList items={product} maxCount={prodMax} />
              )}
            </div>
          </Card>
        </div>


        {/* CUSTOMER */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: SPACING.cardGap,
          }}
        >
          <Card>
            <CardHeader
              title="Customer by Month"
              extra={
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  {[
                    { color: "#0ea5e9", label: "Total" },
                    { color: "#22c55e", label: "New" },
                  ].map(({ color, label }) => (
                    <div
                      key={label}
                      style={{ display: "flex", alignItems: "center", gap: 5 }}
                    >
                      <span
                        style={{
                          display: "block",
                          width: 18,
                          height: 2,
                          borderRadius: 99,
                          background: color,
                        }}
                      />
                      <span
                        style={{
                          fontSize: 10,
                          color: "var(--c-muted)",
                          fontWeight: 600,
                        }}
                      >
                        {label}
                      </span>
                    </div>
                  ))}
                </div>
              }
            />
            <div style={{ padding: SPACING.cardPadding, height: 220 }}>
              {loading ? (
                <ChartSkeleton bars={12} />
              ) : (
                <CustomerLineChart
                  data={customer}
                  gridColor={gridColor}
                  tickColor={tickColor}
                />
              )}
            </div>
          </Card>

          <Card>
            <CardHeader title="New Customer" />
            <div style={{ padding: SPACING.cardPadding, height: 220 }}>
              {loading ? (
                <ChartSkeleton bars={12} />
              ) : (
                <NewCustomerBarChart
                  data={customer}
                  gridColor={gridColor}
                  tickColor={tickColor}
                  isDark={isDark}
                />
              )}
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}